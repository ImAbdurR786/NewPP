/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.dao;

import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.bean.Transaction;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class BankDAO {

	HashMap<Long, Customer> hashMap = new HashMap<Long, Customer>();
	HashMap<Long, Transaction> transactionHashMap = new HashMap<Long, Transaction>();
	HashMap<Long, Transaction> trans = new HashMap<Long, Transaction>();

	public long createAccount(Customer customer, Transaction transaction) {
		hashMap.put(customer.getAccountNo(), customer);
		transactionHashMap.put(transaction.getAccountno(), transaction);
		return customer.getAccountNo();
	}

	public HashMap<Long, Customer> getHashMap() {
		return hashMap;
	}

	public int depositeMoney(long accountNumber, int totalbal, Transaction transaction) {
		hashMap.get(accountNumber).setBalance(totalbal);
		transactionHashMap.put(transaction.getAccountno(), transaction);
		return hashMap.get(accountNumber).getBalance();
	}

	public int withdrawMoney(long accountNumbr, int totalbal, Transaction transaction) {
		hashMap.get(accountNumbr).setBalance(totalbal);
		transactionHashMap.put(transaction.getAccountno(), transaction);
		return hashMap.get(accountNumbr).getBalance();
	}

	public void fundTransfer(long fromaccountNo, long toaccountNo, int totalWithdraw, int totalDeposite,
			Transaction transaction, Transaction transaction1) {
		hashMap.get(fromaccountNo).setBalance(totalWithdraw);
		hashMap.get(toaccountNo).setBalance(totalDeposite);
		transactionHashMap.put(transaction.getAccountno(), transaction);
		transactionHashMap.put(transaction1.getAccountno(), transaction1);
	}

	public HashMap<Long, Transaction> printTransaction(long acountNo) {
		Set<Long> keys = transactionHashMap.keySet();
		Iterator<Long> itr = keys.iterator();
		Long key;
		while (itr.hasNext()) {
			key = itr.next();
			if (key == acountNo) {
				trans.put(key, transactionHashMap.get(key));
			}

		}

		return trans;
	}

}

package com.cg.collection.pp.exception;

public class UserDefineException extends RuntimeException{

    public UserDefineException(String message) {
        System.out.println(message);
    }
   
}

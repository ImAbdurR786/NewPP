package com.bank.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bank.entities.Bank;
import com.bank.entities.Transaction;

@Repository("dao")
@Transactional
public class BankDAO implements BankDaoI {

	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	Random random = new Random();

	@Override
	public boolean createAccount(Bank bank) {
		entityManager.persist(bank);
		return true;
	}

	@Override
	public int showBalance(long accountNo) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		int balance = bank.getBalance();
		return balance;
	}

	@Override
	public int depositBalance(long accountNo, int deposit) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		int bal = bank.getBalance();
		int bal1 = bal + deposit;
		bank.setBalance(bal1);

		Transaction tran = new Transaction();
		tran.setAmount(deposit);
		tran.setTransactionId(random.nextInt(100000));
		tran.setTransactionType("Deposit");
		tran.setBank(bank);

		entityManager.persist(tran);
		entityManager.merge(bank);

		return bal1;
	}

	@Override
	public int withdrawAmount(long accountNo, int withdraw) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		int originalBalance = bank.getBalance();
		int totalBalance = originalBalance - withdraw;
		bank.setBalance(totalBalance);

		Transaction transactionDetails = new Transaction();
		transactionDetails.setAmount(withdraw);
		transactionDetails.setTransactionId(random.nextInt(100000));
		transactionDetails.setTransactionType("Withdraw");
		transactionDetails.setBank(bank);
		entityManager.persist(transactionDetails);
		entityManager.merge(bank);

		return totalBalance;
	}

	@Override
	public boolean fundTransfer(long accountNo, long accno, int amount) {
		boolean b = false;
		Bank bank = entityManager.find(Bank.class, accountNo);
		Bank bank1 = entityManager.find(Bank.class, accno);
		if (bank.getBalance() <= amount) {
			b = false;
		} else {
			int originalBalance = bank.getBalance();
			int originalBalance_1 = bank1.getBalance();
			int totalBalance = originalBalance_1 + amount;
			int totalBalance_1 = originalBalance - amount;

			bank1.setBalance(totalBalance);
			Transaction transactionDetails_2 = new Transaction();
			transactionDetails_2.setAmount(amount);
			transactionDetails_2.setTransactionId(random.nextInt(100000));
			transactionDetails_2.setTransactionType("Fund transfer");
			transactionDetails_2.setBank(bank1);
			transactionDetails_2.setFromAccount(accno);
			entityManager.persist(transactionDetails_2);

			bank.setBalance(totalBalance_1);
			Transaction transactionDetails_3 = new Transaction();
			transactionDetails_3.setAmount(amount);
			transactionDetails_3.setTransactionId(random.nextInt(100000));
			transactionDetails_3.setTransactionType("fund transfer");
			transactionDetails_3.setBank(bank);
			transactionDetails_3.setFromAccount(accountNo);
			entityManager.persist(transactionDetails_3);
			b = true;
		}
		return b;
	}

	@Override
	public boolean validateAccount(long accountNo, String password) {
		boolean b = false;
		Bank bank1 = entityManager.find(Bank.class, accountNo);
		if (bank1 == null) {
			b = false;
		} else {
			String pass = bank1.getPassword();
			System.out.println(pass);
			if (password.equals(pass)) {
				b = true;
			} else {
				b = false;
			}
		}
		return b;
	}

	@Override
	public List<Transaction> getTransactions(long accountNo) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		TypedQuery<Transaction> query = entityManager.createQuery("Select t from Transaction as t where t.bank=:bank",
				Transaction.class);
		query.setParameter("bank", bank);
		List<Transaction> list = query.getResultList();
		return list;
	}

}